﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace AvengerMisionesMVC.Models
{
    public class AvengerDBContext:DbContext
    {

        //Declaracion de la base de datos asignandole el nombre de AvengerDBcontext 
        public AvengerDBContext() : base("name=AvengerDBContext"){}
        //Creacion del CRUD de la clase Heroe
        public DbSet<Heroe> Heroes { get; set; }
        //Creacion del CRUD de la clase Misiones
        public DbSet<Mision> Misiones { get; set; }
    }
}