﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace AvengerMisionesMVC.Models
{
    public class Mision
    {    //Valida que el campo de id no este vacio y lo identifica como clave para evitar duplicados
        [Key]
        public int IDMision { get; set; }
        //Valida que el campo de titulo no este vacio
        [Required]
        public string Titulo { get; set; }
        public string Amenaza { get; set; }
        public string Estado { get; set; }

        public string IdHeroe { get; set; }
        //declara una propieda llamada Heroe que permite manipular un objeto Heroe
        public virtual Heroe Heroe { get; set; }
    }
}