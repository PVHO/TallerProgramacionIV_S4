﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace AvengerMisionesMVC.Models
{
    public class Heroe
    {    //Valida que el campo de id no este vacio y lo identifica como clave para evitar duplicados
        [Key]
        public int IdHeroe { get; set; }
        //valida que el campo  de alias no este vacio
        [Required]
        public string Alias { get; set; }
        //valida que el campo de nombre no este vacio
        [Required]
        public string Nombre { get; set; }
        //declara una propiedad llamada  Mision que permite manejrar una coleccion de objeto de misiones
        public virtual ICollection<Mision> Misiones { get; set; }
    }
}