﻿namespace AvengerMisionesMVC.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Inicial : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Heroes",
                c => new
                    {
                        IdHeroe = c.Int(nullable: false, identity: true),
                        Alias = c.String(nullable: false),
                        Nombre = c.String(nullable: false),
                    })
                .PrimaryKey(t => t.IdHeroe);
            
            CreateTable(
                "dbo.Misions",
                c => new
                    {
                        IDMision = c.Int(nullable: false, identity: true),
                        Titulo = c.String(nullable: false),
                        Amenaza = c.String(),
                        Estado = c.String(),
                        IdHeroe = c.String(),
                        Heroe_IdHeroe = c.Int(),
                    })
                .PrimaryKey(t => t.IDMision)
                .ForeignKey("dbo.Heroes", t => t.Heroe_IdHeroe)
                .Index(t => t.Heroe_IdHeroe);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Misions", "Heroe_IdHeroe", "dbo.Heroes");
            DropIndex("dbo.Misions", new[] { "Heroe_IdHeroe" });
            DropTable("dbo.Misions");
            DropTable("dbo.Heroes");
        }
    }
}
