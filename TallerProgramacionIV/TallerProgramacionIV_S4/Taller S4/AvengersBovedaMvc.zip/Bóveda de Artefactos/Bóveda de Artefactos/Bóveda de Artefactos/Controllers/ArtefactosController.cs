﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Bóveda_de_Artefactos.Models;

namespace Bóveda_de_Artefactos.Controllers
{
    public class ArtefactosController : Controller
    {
        private DBContext db = new DBContext();

        // GET: Artefactos
        public ActionResult Index()
        {
            var artefactos = db.Artefactos.Include(a => a.Boveda);
            return View(artefactos.ToList());
        }

        // GET: Artefactos/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Artefacto artefacto = db.Artefactos.Find(id);
            if (artefacto == null)
            {
                return HttpNotFound();
            }
            return View(artefacto);
        }

        // GET: Artefactos/Create
        public ActionResult Create()
        {
            ViewBag.BovedaId = new SelectList(db.Bovedas, "BovedaId", "NombreBoveda");
            return View();
        }

        // POST: Artefactos/Create
        // Para protegerse de ataques de publicación excesiva, habilite las propiedades específicas a las que quiere enlazarse. Para obtener 
        // más detalles, vea https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "ArtefactoId,NombreArtefacto,Energia,Poseedor,BovedaId")] Artefacto artefacto)
        {
            if (ModelState.IsValid)
            {
                db.Artefactos.Add(artefacto);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.BovedaId = new SelectList(db.Bovedas, "BovedaId", "NombreBoveda", artefacto.BovedaId);
            return View(artefacto);
        }

        // GET: Artefactos/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Artefacto artefacto = db.Artefactos.Find(id);
            if (artefacto == null)
            {
                return HttpNotFound();
            }
            ViewBag.BovedaId = new SelectList(db.Bovedas, "BovedaId", "NombreBoveda", artefacto.BovedaId);
            return View(artefacto);
        }

        // POST: Artefactos/Edit/5
        // Para protegerse de ataques de publicación excesiva, habilite las propiedades específicas a las que quiere enlazarse. Para obtener 
        // más detalles, vea https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "ArtefactoId,NombreArtefacto,Energia,Poseedor,BovedaId")] Artefacto artefacto)
        {
            if (ModelState.IsValid)
            {
                db.Entry(artefacto).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.BovedaId = new SelectList(db.Bovedas, "BovedaId", "NombreBoveda", artefacto.BovedaId);
            return View(artefacto);
        }

        // GET: Artefactos/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Artefacto artefacto = db.Artefactos.Find(id);
            if (artefacto == null)
            {
                return HttpNotFound();
            }
            return View(artefacto);
        }

        // POST: Artefactos/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Artefacto artefacto = db.Artefactos.Find(id);
            db.Artefactos.Remove(artefacto);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
