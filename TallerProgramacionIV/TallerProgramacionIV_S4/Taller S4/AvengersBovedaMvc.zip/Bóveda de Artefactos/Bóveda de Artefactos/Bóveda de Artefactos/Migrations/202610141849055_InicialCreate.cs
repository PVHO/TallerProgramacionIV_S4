﻿namespace Bóveda_de_Artefactos.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class InicialCreate : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Artefactoes",
                c => new
                    {
                        ArtefactoId = c.Int(nullable: false, identity: true),
                        Nombre = c.String(nullable: false, maxLength: 60),
                        Energia = c.Int(nullable: false),
                        Poseedor = c.String(),
                        BovedaId = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.ArtefactoId)
                .ForeignKey("dbo.Bovedas", t => t.BovedaId, cascadeDelete: true)
                .Index(t => t.BovedaId);
            
            CreateTable(
                "dbo.Bovedas",
                c => new
                    {
                        BovedaId = c.Int(nullable: false, identity: true),
                        Nombre = c.String(nullable: false, maxLength: 60),
                        Ubicacion = c.String(),
                    })
                .PrimaryKey(t => t.BovedaId);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Artefactoes", "BovedaId", "dbo.Bovedas");
            DropIndex("dbo.Artefactoes", new[] { "BovedaId" });
            DropTable("dbo.Bovedas");
            DropTable("dbo.Artefactoes");
        }
    }
}
