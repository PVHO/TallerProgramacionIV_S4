﻿namespace Bóveda_de_Artefactos.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class ActualizarModelo : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Artefactoes", "NombreArtefacto", c => c.String(nullable: false, maxLength: 60));
            AddColumn("dbo.Bovedas", "NombreBoveda", c => c.String(nullable: false, maxLength: 60));
            DropColumn("dbo.Artefactoes", "NombreBoveda");
            DropColumn("dbo.Bovedas", "Nombre");
        }
        
        public override void Down()
        {
            AddColumn("dbo.Bovedas", "Nombre", c => c.String(nullable: false, maxLength: 60));
            AddColumn("dbo.Artefactoes", "NombreBoveda", c => c.String(nullable: false, maxLength: 60));
            DropColumn("dbo.Bovedas", "NombreBoveda");
            DropColumn("dbo.Artefactoes", "NombreArtefacto");
        }
    }
}
