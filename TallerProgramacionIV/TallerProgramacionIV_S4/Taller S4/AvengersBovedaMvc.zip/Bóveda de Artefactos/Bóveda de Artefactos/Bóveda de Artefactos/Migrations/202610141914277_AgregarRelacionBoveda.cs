﻿namespace Bóveda_de_Artefactos.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AgregarRelacionBoveda : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Artefactoes", "NombreBoveda", c => c.String(nullable: false, maxLength: 60));
            DropColumn("dbo.Artefactoes", "Nombre");
        }
        
        public override void Down()
        {
            AddColumn("dbo.Artefactoes", "Nombre", c => c.String(nullable: false, maxLength: 60));
            DropColumn("dbo.Artefactoes", "NombreBoveda");
        }
    }
}
