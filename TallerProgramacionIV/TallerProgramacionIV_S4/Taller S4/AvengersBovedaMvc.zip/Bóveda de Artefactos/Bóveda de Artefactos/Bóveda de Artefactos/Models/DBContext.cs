﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace Bóveda_de_Artefactos.Models
{
    public class DBContext : DbContext
    {

        public DBContext() : base("Name=BDArtefactos") { }

        public DbSet<Artefacto> Artefactos { get; set; } //Lista de artefactos

        public System.Data.Entity.DbSet<Bóveda_de_Artefactos.Models.Boveda> Bovedas { get; set; } //Lista de bovedas
    }
}