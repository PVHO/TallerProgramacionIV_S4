﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;



namespace Bóveda_de_Artefactos.Models
{
    public class Boveda
    {

        [Key] //identificador único para la boveda
        public int BovedaId { get; set; }

        [Required]
        [StringLength(60)] //máximo 60 caracteres
        public string NombreBoveda { get; set; }


        public string Ubicacion { get; set; }

       


    }


}