﻿using System.ComponentModel.DataAnnotations;


namespace Bóveda_de_Artefactos.Models
{
    public class Artefacto
    {

        [Key]
        public int ArtefactoId { get; set; }


        [Required]
        [StringLength(60)] //máximo 60 caracteres
        public string NombreArtefacto { get; set; }


        [Range(0, 100)]
        public int Energia { get; set; }

        public string Poseedor { get; set; }



        public virtual Boveda Boveda { get; set; }
        public int BovedaId { get; set; }


    }
}